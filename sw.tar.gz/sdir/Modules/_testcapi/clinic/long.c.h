/*[clinic input]
preserve
[clinic start generated code]*/

PyDoc_STRVAR(_testcapi_call_long_compact_api__doc__,
"call_long_compact_api($module, arg, /)\n"
"--\n"
"\n");

#define _TESTCAPI_CALL_LONG_COMPACT_API_METHODDEF    \
    {"call_long_compact_api", (PyCFunction)_testcapi_call_long_compact_api, METH_O, _testcapi_call_long_compact_api__doc__},
/*[clinic end generated code: output=0ddcbc6ea06e5e21 input=a9049054013a1b77]*/
